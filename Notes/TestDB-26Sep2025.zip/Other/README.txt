
Test DataBase


This revision of "Test DataBase" completely replaces all previous revisions
and publications.

Much of this information was received from living members of the various
families, from other researchers, from Web Sites, etc. In these cases I
have not verified the information in many instances and proving the factual
basis of the enclosed data is left as an exercise for those who would like
to perform further research. I have omitted information where there seems
to be obvious errors. Each piece of information has been cited. This should
facilitate further research if desired. Any information where original
source documents are not cited should be questioned. And any information
where source documents are indeed cited could possibly be misinterpreted.
Always double check for accuracy.

The Test DataBase DataBase can be used from the media that you received. But,
to speed up processing, copy the Test DataBase DataBase to your hard drive
and access it there.


I'm open to any and all suggestions, corrections, updates, additions,
questions or comments anyone might have concerning the presentation and/or
accuracy of the content herein.

Marshall Lake
MarshallELake@gmail.com
sot2@mlake.net
https://mlake.net



The content of this database is organized as such ...

BOOK
  HTML             (HTML version of "Test DataBase", if created)
  Images           (images associated with "Test DataBase")
  PlainText        (plain text version of "Test DataBase")
  Reference        (plain text citation/source information)
  UnsureIfRelated  (info regarding people who may or may not be genealogically
                   related to people in "Test DataBase")
  Other            (help, Test DataBase-related info, and miscellaneous general
                   info)

All the images in the "Images" sub-directory are referenced in the plain text
version.  In the HTML version, if created, all the images are appropriately
linked and are easily brought up on a computer display (which is one reason
why the HTML version is the best version for viewing on a computer).

